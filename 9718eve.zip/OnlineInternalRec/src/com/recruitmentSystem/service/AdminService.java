package com.recruitmentSystem.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.recruitmentSystem.bean.UserBean;
import com.recruitmentSystem.dao.AdminDAOImpl;
import com.recruitmentSystem.dao.IAdminDAO;
import com.recruitmentSystem.exception.OIRSException;

public class AdminService implements IAdminService{

	
	/*******************************************************************************************************
	 - Function Name	:	addNewUser()
	 - Input Parameters	:	userBean
	 - Return Type		:	String
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	return String
	 ********************************************************************************************************/
	@Override
	public String addNewUser(UserBean userBean) throws OIRSException {
		
		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.addNewUser(userBean);
		
	}

	/*******************************************************************************************************
	 - Function Name	:	assignRole()
	 - Input Parameters	:	userId, role
	 - Return Type		:	String
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	return String
	 ********************************************************************************************************/
	@Override
	public String assignRole(String userId, String role) throws OIRSException {

		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.assignRole(userId, role);
	}

	
	/*******************************************************************************************************
	 - Function Name	:	deleteUser()
	 - Input Parameters	:	userId
	 - Return Type		:	String
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	return String
	 ********************************************************************************************************/
	@Override
	public String deleteUser(String userId) throws OIRSException {

		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.deleteUser(userId);
	}

	@Override
	public void generateReport() throws OIRSException {
		
		return ;
	}

	
	/*******************************************************************************************************
	 - Function Name	:	getUserId()
	 - Input Parameters	:	
	 - Return Type		:	List<String>
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	return String
	 ********************************************************************************************************/
	@Override
	public boolean isValidUserid(String uid) {
		Pattern p=Pattern.compile("[A-Z][a-z][0-9]{2,}");
		Matcher m=p.matcher(uid);
		boolean r=m.matches();
		if(m.matches())
			return true;
		else
		{
			System.err.println("Enter valid user id");
			return false;
		}
		
		
	}

	
	/*******************************************************************************************************
	 - Function Name	:	isValidPassword()
	 - Input Parameters	:	pwd
	 - Return Type		:	boolean
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	Validating Password
	 ********************************************************************************************************/
	@Override
	public boolean isValidPassword(String pwd) {
		Pattern p=Pattern.compile("[A-Za-z0-9]{8}");
		Matcher m=p.matcher(pwd);
		if(m.matches())
		{
			return true;
		}
		else
		{
			System.err.println("Invalid Password");
			return false;
		}
	}

	
	/*******************************************************************************************************
	 - Function Name	:	getUserId()
	 - Input Parameters	:	
	 - Return Type		:	List<String>
	 - Throws		    :  	OIRSException
	 - Author	     	:	SINDHU, SIREESHA
	 - Creation Date	:	07/07/2018
	 - Description		:	return String
	 ********************************************************************************************************/
	@Override
	public List<String> getUserIds() throws OIRSException {
		// TODO Auto-generated method stub
		IAdminDAO iadmindao=new AdminDAOImpl();
		List<String> list = iadmindao.getUserIds();
		return list;
	}
}