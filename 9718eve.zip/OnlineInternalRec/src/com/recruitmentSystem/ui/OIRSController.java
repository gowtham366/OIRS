package com.recruitmentSystem.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.recruitmentSystem.bean.UserBean;
import com.recruitmentSystem.exception.OIRSException;
import com.recruitmentSystem.service.AdminService;
import com.recruitmentSystem.service.AuthenticateServiceImpl;
import com.recruitmentSystem.service.IAdminService;
import com.recruitmentSystem.service.IAuthenticateService;
import com.recruitmentSystem.service.IRMGEService;
import com.recruitmentSystem.service.IRMService;
import com.recruitmentSystem.service.RMServiceImpl;

/**
 * Servlet implementation class OIRSController
 */
@WebServlet("/OIRSController")
public class OIRSController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OIRSController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */


	IAdminService adminService;
	IRMService rmService;
	IRMGEService rmgeService;
	UserBean userBean;
	IAuthenticateService authService = new AuthenticateServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		if(action!=null){
			//out.print(request.getServletPath()+" "+action);
			if(action.equalsIgnoreCase("Login")){
				String UserId = request.getParameter("userId");
				String userPassword = request.getParameter("userPassword");
				try {
					userBean = authService.loginUser(UserId, userPassword);
					if(userBean != null){
						
						String userRole = userBean.getUserRole();
						String lastLogin =  userBean.getLastLogin();
						System.out.println("Last login : "+lastLogin);
							
						HttpSession session = request.getSession(true);
						session.setAttribute("userId", userBean.getUserId());
						session.setAttribute("userRole", userBean.getUserRole());
						session.setAttribute("UserBean", userBean);
						session.setAttribute("logindate",lastLogin);
						response.setStatus(200);
						if(userRole.equalsIgnoreCase("admin")){
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/AdminPage.jsp");
							rd.include(request, response);
							//out.print("<font color=green>Login Success!!!</font>");
						}
						else if(userRole.equalsIgnoreCase("rm")){
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/RmPage.jsp.jsp");
							rd.include(request, response);
						}
						else if(userRole.equalsIgnoreCase("rmge")){
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/RmgePage.jsp");
							rd.include(request, response);
						}
					}
					else
					{
						response.setStatus(401);
						RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
						rd.include(request, response);
						out.print("<font color=red>Invalid login details</font>");
					}
				
				}catch (OIRSException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
					rd.include(request, response);
					out.print("<font color=red>Database Connection Failed</font>");
				}			

			}//action=login
			
			
			//add new user
			else if(action.equalsIgnoreCase("Add New User")){
				RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
				rd.forward(request, response);	
			}
			
			
			//Assign Role
			else if(action.equals("Assign Role")){
				
			}
			

		}//action!=null
		else{
			//request.getServletPath();
			RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
			rd.include(request, response);
			out.print("<font color=red>Something went wrong!!!</font>");
		}

	}

}
