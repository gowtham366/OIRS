package com.recruitmentSystem.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.recruitmentSystem.bean.UserBean;
import com.recruitmentSystem.exception.OIRSException;
import com.recruitmentSystem.service.AdminService;
import com.recruitmentSystem.service.AuthenticateServiceImpl;
import com.recruitmentSystem.service.IAdminService;
import com.recruitmentSystem.service.IAuthenticateService;
import com.recruitmentSystem.service.IRMGEService;
import com.recruitmentSystem.service.IRMService;
import com.recruitmentSystem.service.RMGEServiceImpl;
import com.recruitmentSystem.service.RMServiceImpl;

/**
 * Servlet implementation class OIRSController
 */
@WebServlet("/OIRSController")
public class OIRSController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OIRSController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */


	IAdminService adminService;
	IRMService rmService;
	IRMGEService rmgeService;
	UserBean userBean;
	IAuthenticateService authService = new AuthenticateServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		if(action!=null){
			//out.print(request.getServletPath()+" "+action);
			if(action.equalsIgnoreCase("Login")){
				String UserId = request.getParameter("userId");
				String userPassword = request.getParameter("userPassword");
				try {
					//userPassword = adminService.encryptPassword(userPassword);
					userBean = authService.loginUser(UserId, userPassword);
					if(userBean != null){

						String userRole = userBean.getUserRole();
						String lastLogin =  userBean.getLastLogin();
						System.out.println("Last login : "+lastLogin);

						HttpSession session = request.getSession(true);
						session.setAttribute("userId", userBean.getUserId());
						session.setAttribute("userRole", userBean.getUserRole());
						session.setAttribute("UserBean", userBean);
						session.setAttribute("logindate",lastLogin);
						response.setStatus(200);
						if(userRole.equalsIgnoreCase("admin")){
							adminService = new AdminService();
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/AdminPage.jsp");
							rd.include(request, response);
							//out.print("<font color=green>Login Success!!!</font>");
						}
						else if(userRole.equalsIgnoreCase("rm")){
							rmService = new RMServiceImpl();
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/RmPage.jsp.jsp");
							rd.include(request, response);
						}
						else if(userRole.equalsIgnoreCase("rmge")){
							rmgeService = new RMGEServiceImpl();
							response.setStatus(200);
							RequestDispatcher rd=request.getRequestDispatcher("/RmgePage.jsp");
							rd.include(request, response);
						}
					}
					else
					{
						response.setStatus(401);
						RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
						rd.include(request, response);
						out.print("<font color=red>Invalid login details</font>");
					}

				}catch (OIRSException e) {

					RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
					rd.include(request, response);
					out.print("<font color=red>Database Connection Failed</font>");
				}			

			}//action=login


			//logout
			else if(action.equalsIgnoreCase("logout")){

				HttpSession session=request.getSession(false);
				session.invalidate();
				RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
				rd.include(request, response);
				out.print("<font color=green>Logged out sucessfully!!</font>");

			}


			//redirect to add new user form page
			else if(action.equalsIgnoreCase("Add New User")){
				RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
				rd.forward(request, response);	
			}

			else if(action.equals("Add User"))
			{
				String userId = request.getParameter("userId");
				String userPassword = request.getParameter("userPassword");
				String userConfirmPassword = request.getParameter("userConfirmPassword");
				String userRole = request.getParameter("userRole").toLowerCase();
				String userHint = request.getParameter("userHint").toLowerCase();

				if(userPassword.equals(userConfirmPassword)){
					UserBean addUserBean = new UserBean();
					addUserBean.setUserId(userId);
					addUserBean.setUserRole(userRole);
					addUserBean.setHint(userHint);

					try {
						//System.out.println(adminService.encryptPassword(userPassword));
						//String encryptedPassword = adminService.encryptPassword(userPassword);
						//addUserBean.setUserPassword(encryptedPassword);
						addUserBean.setUserPassword(userPassword);
						String result = adminService.addNewUser(addUserBean);
						System.out.println(result);
						if(result == null){
							RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
							rd.include(request, response);
							out.print("<font color=red>User already exist</font>");
						}
						else{
							RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
							rd.include(request, response);
							out.print("<font color=green>User added succesfully!!!</font>");
						}
					} catch (OIRSException e) {
						RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
						rd.include(request, response);
						out.print("<font color=red>User already exist</font>");
					}					

				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/addUser.jsp");
					rd.include(request, response);
					out.print("<font color=red>Password and Confirm Password must be same</font>");
				}


			}

			//Assign Role form
			else if(action.equals("Assign Role")){
				try {
					HttpSession session=request.getSession(false);
					List<UserBean> list = adminService.getUserDetails();
					request.setAttribute("userDetails", list);
					RequestDispatcher rd=request.getRequestDispatcher("/assignRole.jsp");
					rd.include(request, response);
				} catch (OIRSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 

			}
			
			//Assign Role
			else if(action.equals("Assign"))
			{
				String assignUserId = request.getParameter("assignId");
				String assignRole = request.getParameter("assignRole");
				
				//userbean.setUserId(assignUserId);
				//userbean.setUserRole(assignRole);
				try {
					String res = adminService.assignRole(assignUserId, assignRole);
					if(res==null){
						out.println("User not found!!! Enter the valid user ID");
					}
					else
					{				
						try {
							List<String> list = adminService.getUserIds();
							request.setAttribute("userIds", list);
							getServletContext().getRequestDispatcher("/assignRole.jsp").include(request,response);
							out.print("<h2>User role assigned successfully!!</h2><br>");
							
						} catch (OIRSException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
						//out.println("succesfully assigned role");
					}
				} catch (OIRSException e) {
					System.out.println(e.getMessage());
				}
			}


		}//action!=null
		else{
			//request.getServletPath();
			RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
			rd.include(request, response);
			out.print("<font color=red>Something went wrong!!!</font>");
		}

	}

}
