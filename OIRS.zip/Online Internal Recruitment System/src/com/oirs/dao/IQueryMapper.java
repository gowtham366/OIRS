package com.oirs.dao;

public interface IQueryMapper {
	
	//gowtham team //AUTHENTICATION
	public static final String QUERY_AUTH_USER ="SELECT user_id,role,last_login FROM tbl_user_master WHERE user_id = ? AND password = ?";
	public static final String QUERY_SEARCH_EMPLOYEE = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,rm_id FROM tbl_employee_master WHERE domain = ? AND skill = ? AND experience_yrs = ?";
	

	
	//Sindhu team //ADMIN
	public static final String VIEWUSER="SELECT user_id FROM tbl_user_master";
	public static final String ADDUSER="INSERT INTO tbl_user_master VALUES(?,?,?,SYSDATE,?)";
	public static final String ASSIGNROLE="UPDATE tbl_user_master SET role = ? WHERE user_id = ?";
	public static final String DELETEUSER="DELETE FROM tbl_user_master WHERE user_id=?";
	public static final String GET_USER_IDS = "SELECT user_id FROM tbl_user_master"; 
	
	//RM
	public static final String QUERY_COUNT_REQ = "SELECT COUNT(*) FROM tbl_requisition";
	public static final String QUERY_VIEW_PROJECTS = "SELECT project_id,rm_id,project_name,description,start_date,end_date FROM tbl_project_master WHERE rm_id = ?";
	public static final String QUERY_RAISE_REQ = "INSERT INTO tbl_requisition (requisition_id,rm_id,project_id,date_created,current_status,vacancy_name,skill,domain,number_required) VALUES(?,?,?,SYSDATE,'OPEN',?,?,?,?)";
	public static final String QUERY_VIEW_ALL_REQUISITION = "SELECT requisition_id,rm_id,project_id,date_created,date_closed,current_status,vaccancy_name,skill,domain,number_required FROM tbl_requisition WHERE rm_id = ?";
	public static final String QUERY_VIEW_REQUISITION_BY_STATUS = "SELECT requisition_id,rm_id,project_id,date_created,date_closed,current_status,vaccancy_name,skill,domain,number_required FROM tbl_requisition WHERE rm_id = ? AND current_status = ? ";
	public static final String QUERY_VACCANCY_COUNT_PRJID = "SELECT number_required,project_id FROM tbl_requisition WHERE requisition_id = ?";
	public static final String QUERY_VIEW_REQ_RES = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,req_id FROM tbl_employee_master WHERE req_id = ?";
	public static final String QUERY_UPDATE_RES = "UPDATE tbl_employee_master SET project_id = ? WHERE employee_id = ?";
	public static final String QUERY_DEC_NUMBER_REQ = "UPDATE tbl_requisition SET number_required = ? WHERE requisition_id = ?";
	public static final String QUERY_UNASSIGN_PROJECT = "UPDATE tbl_employee_master SET project_id = 'rmg' WHERE  employee_id = ?";
 	public static final String QUERY_UNASSIGN_PROJECT_BY_PRJID = "UPDATE tbl_employee_master SET project_id = 'rmg' WHERE project_id = ?";
 	public static final String QUERY_CLOSE_REQ_BY_PRJID = "UPDATE tbl_requisition SET date_closed = SYSDATE WHERE project_id = ?";
 	public static final String QUERY_CLOSE_REQ_BY_REQID = "UPDATE tbl_requisition SET date_closed = SYSDATE WHERE requisition_id = ?";
 	public static final String QUERY_CLOSE_PROJECT = "UPDATE tbl_project_master SET end_date = SYSDATE WHERE project_id = ?";
	public static final String QUERY_VIEW_EMPLOYEES_BY_PROJECTID = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,rm_id FROM tbl_employee_master WHERE project_id = ?";
	
	//Gowtham \\RMGE
	public static final String QUERY_GET_RM_IDS = "SELECT rm_id FROM tbl_requisition";
	public static final String QUERY_ASSIGN_PROJECT = "UPDATE tbl_employee_master SET req_id =? WHERE employee_id = ?";
	public static final String QUERY_GET_EMPLOYEE_DETAILS_BY_REQID = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,req_id FROM tbl_employee_master WHERE req_id = ?";
	public static final String QUERY_GET_ALL_REQ = "SELECT requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required FROM tbl_requisition";
	public static final String QUERY_GET_REQ_RMID = "SELECT requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required FROM tbl_requisition WHERE rm_id = ? AND number_required>0";
	public static final String QUERY_GET_REQ_BY_REQID = "SELECT requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required FROM tbl_requisition WHERE requisition_id = ?";
	public static final String QUERY_RMGE_SEARCH_EMPLOYEE = "SELECT employee_id,employee_name,skill,domain,experience_yrs,project_id,req_id FROM tbl_employee_master WHERE skill = ? AND domain = ? AND project_id = 'RMG' AND req_id IS NULL";
	
}
