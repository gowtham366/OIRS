package com.oirs.exception;

public class OIRSException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7702458176365160755L;
	
	public OIRSException() {
		// TODO Auto-generated constructor stub
	}
	
	public OIRSException(String msg) {
		super(msg);
	}
	
}
