package com.oirs.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oirs.bean.userBean;
import com.oirs.dao.AdminDAOImpl;
import com.oirs.dao.IAdminDAO;
import com.oirs.exception.OIRSException;

public class AdminService implements IAdminService{

	@Override
	public String addNewUser(userBean userBean) throws OIRSException {
		
		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.addNewUser(userBean);
		
	}

	@Override
	public String assignRole(String userId, String role) throws OIRSException {

		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.assignRole(userId, role);
	}

	@Override
	public String deleteUser(String userId) throws OIRSException {

		IAdminDAO iadmindao=new AdminDAOImpl();
		return iadmindao.deleteUser(userId);
	}

	@Override
	public void generateReport() throws OIRSException {
		
		return ;
	}

	@Override
	public boolean isValidUserid(String uid) {
		Pattern p=Pattern.compile("[A-Z][a-z][0-9]{2,}");
		Matcher m=p.matcher(uid);
		boolean r=m.matches();
		if(m.matches())
			return true;
		else
		{
			System.err.println("Enter valid user id");
			return false;
		}
		
		
	}

	@Override
	public boolean isValidPassword(String pwd) {
		Pattern p=Pattern.compile("[A-Za-z0-9]{8}");
		Matcher m=p.matcher(pwd);
		if(m.matches())
		{
			return true;
		}
		else
		{
			System.err.println("Invalid Password");
			return false;
		}
	}

	@Override
	public List<String> getUserIds() throws OIRSException {
		// TODO Auto-generated method stub
		IAdminDAO iadmindao=new AdminDAOImpl();
		List<String> list = iadmindao.getUserIds();
		return list;
	}
}