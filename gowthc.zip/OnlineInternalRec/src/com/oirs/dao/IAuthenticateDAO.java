package com.oirs.dao;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

public interface IAuthenticateDAO {
	public UserBean loginUser(String userId,String userPass) throws OIRSException;
}
