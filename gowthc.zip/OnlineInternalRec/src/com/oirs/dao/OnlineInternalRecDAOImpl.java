package com.oirs.dao;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

public class OnlineInternalRecDAOImpl implements IOnlineInternalRecDAO {

	@Override
	public UserBean loginUser(String userName, String userPassword)
			throws OIRSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validatingUser(String Id, String password) {
		// TODO Auto-generated method stub
		return false;
	}

}
