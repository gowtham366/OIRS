package com.oirs.service;

import com.oirs.bean.UserBean;
import com.oirs.dao.AuthenticateDAOImpl;
import com.oirs.dao.IAuthenticateDAO;
import com.oirs.exception.OIRSException;

public class AuthenticateServiceImpl implements IAuthenticateService {

	IAuthenticateDAO iAuthenticateDAO = new AuthenticateDAOImpl();
	UserBean bean = null;
	@Override
	public UserBean loginUser(String userId, String userPass)
			throws OIRSException {
		// TODO Auto-generated method stub
		bean = iAuthenticateDAO.loginUser(userId, userPass);
		return bean;
	}

}
