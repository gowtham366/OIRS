package com.oirs.service;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

public interface IAuthenticateService {
	public UserBean loginUser(String userId,String userPass) throws OIRSException;
}
