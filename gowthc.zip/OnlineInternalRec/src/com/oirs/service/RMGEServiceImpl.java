package com.oirs.service;

import java.util.List;

import oracle.net.aso.i;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.dao.IRMGEDAO;
import com.oirs.dao.RMGEDAOImpl;
import com.oirs.exception.OIRSException;

public class RMGEServiceImpl implements IRMGEService {

	IRMGEDAO iRMGEDAO = new RMGEDAOImpl();
	@Override
	public List<EmployeeBean> searchEmployee(RequisitionBean reqBean)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<EmployeeBean> list = iRMGEDAO.searchEmployee(reqBean);
		return list;
	}

	@Override
	public List<String> getRmIds() throws OIRSException {
		// TODO Auto-generated method stub
		List<String> list = iRMGEDAO.getRmIds();
		return list;
	}

	@Override
	public List<RequisitionBean> getAllRequisitions() throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = iRMGEDAO.getAllRequisitions();
		return list;
	}

	@Override
	public RequisitionBean getRequisitionDetails(String reqId)
			throws OIRSException {
		// TODO Auto-generated method stub

		RequisitionBean bean = iRMGEDAO.getRequisitionDetails(reqId);
		return bean;
	}

	@Override
	public EmployeeBean getEmployeeDetails(String empId) throws OIRSException {
		// TODO Auto-generated method stub
		EmployeeBean bean = iRMGEDAO.getEmployeeDetails(empId);
		return bean;
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatus(String status)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = iRMGEDAO.getRequisitionByStatus(status);
		return list;
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatusRM(String rmId,
			String status) throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = iRMGEDAO.getRequisitionByStatusRM(rmId, status);
		return list;
	}

	@Override
	public List<RequisitionBean> getRequisitionByRMId(String rmId)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = iRMGEDAO.getRequisitionByRMId(rmId);
		return list;
	}

	@Override
	public boolean assignProject(String empId, String reqId)
			throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMGEDAO.assignProject(empId, reqId);
		return result;
	}

	@Override
	public RequisitionBean updateReqNumberAssigned(String reqId, int numAssigned)
			throws OIRSException {
		// TODO Auto-generated method stub
		RequisitionBean bean = iRMGEDAO.updateReqNumberAssigned(reqId, numAssigned);
		return bean;
	}

}
