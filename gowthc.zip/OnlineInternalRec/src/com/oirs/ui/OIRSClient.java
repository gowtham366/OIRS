/**
 * 
 */
package com.oirs.ui;

import java.util.List;
import java.util.Scanner;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;
import com.oirs.service.AdminService;
import com.oirs.service.AuthenticateServiceImpl;
import com.oirs.service.IAdminService;
import com.oirs.service.IAuthenticateService;
import com.oirs.service.IOnlineInternalRecService;
import com.oirs.service.IRMGEService;
import com.oirs.service.IRMService;
import com.oirs.service.OnlineInternalRecServiceImpl;
import com.oirs.service.RMServiceImpl;

/**
 * @author gowthc
 *
 */
public class OIRSClient {

	/**
	 * @param args
	 */

	//Creating objects for Bean classes
	EmployeeBean empBean = new EmployeeBean();
	ProjectBean projectBean = new ProjectBean();
	RequisitionBean reqBean = new RequisitionBean();
	static Scanner scanner = new Scanner(System.in);

	//Main method
	public static void main(String[] args) throws OIRSException {
		
		System.out.println("Online Internal Recruitment System");
		//int option = 0;
		String userId;
		String userPass;
		do{
			System.out.println("Select your option\n1.Login\n2.Exit");
			int option = scanner.nextInt();
			IOnlineInternalRecService service = new OnlineInternalRecServiceImpl();
			IAuthenticateService iAuthenticateService = new AuthenticateServiceImpl();
			UserBean bean = new UserBean();
			switch(option)
			{
			case 1 : {
				do{
					System.out.println("Enter User ID : ");
					userId = scanner.next();
				}while(!(service.isValidUserName(userId)));
				System.out.println("Enter password : ");
				userPass = scanner.next();
				bean = iAuthenticateService.loginUser(userId, userPass);
				if(bean!=null)
				{
					System.out.println("Valid User");
					System.out.println(bean.getUserRole());
					String role = bean.getUserRole().toLowerCase();
					OIRSClient client = new OIRSClient();
					do{
					switch(role)
					{
					case "admin":
					{
						client.adminService(bean);
						break;
					}
					case "rm":
					{
						client.rmService(bean);
						break;
					}
					case "rmge":
					{
						client.rmgeService(bean);
						break;
					}
					}
					System.out.println("Continue again? Y/N");
					}while(scanner.next().equalsIgnoreCase("Y"));
				}
				else{
					System.out.println("Invalid UserId or Password");
				}
				break;
			}
			case 2 : {
				System.exit(0);
				break;
			}
			default : System.out.println("Please enter correct choice : ");
			break;
			}
			System.out.println("Continue again? Y/N");
		}while(scanner.next().equalsIgnoreCase("Y"));
	}

	public void adminService(UserBean bean) throws OIRSException{
		IAdminService admin = new AdminService();
		System.out.println("Admin Service\n1.Add new user\t2.Assign roles\t3.Delete users\t4.Generate Report\t5.Exit");
		int option = scanner.nextInt();
		UserBean adminBean = new UserBean();
		switch(option){
		case 1:
		{
			
			System.out.println("Enter the USER ID : ");
			String userId = scanner.next();
			System.out.println("Enter the password : ");
			String userPass = scanner.next();
			System.out.println("Enter the Password hint : ");
			String hint = scanner.next();
			System.out.println("Enter the role");
			String role = scanner.next().toLowerCase();
			adminBean.setUserId(userId);
			adminBean.setUserPassword(userPass);
			adminBean.setUserRole(role);
			adminBean.setHint(hint);
			String result = admin.addNewUser(adminBean);
			if(result!=null){
				System.out.println(result);
			}
			break;
		}
		case 2:
		{
			System.out.println("Enter the user ID : ");
			String userId = scanner.next();
			System.out.println("Enter the user role : ");
			String role = scanner.next();
			String result = admin.assignRole(userId, role);
			if(result!=null){
				System.out.println(result);
			}
			break;
		}
		case 3:
		{
			System.out.println("Enter the user ID : ");
			String userId = scanner.next();
			String result = admin.deleteUser(userId);
			if(result!=null){
				System.out.println(result);
			}
			break;
		}
		case 4:
		{
			
			break;
		}
		case 5:
			break;
		default:{
			System.out.println("Invalid choice");
		}
		}
		
		
	}

	public void rmService(UserBean bean) throws OIRSException{
		IRMService rm = new RMServiceImpl();
		RequisitionBean reqBean = new RequisitionBean();
		System.out.println("RM Service\n1.Raise Requisition\t2.Accept/Reject resource\t3.Close/unassign project\t4.Generate report\t5.Exit");
		int option = scanner.nextInt();
		String rmId = bean.getUserId();
		switch(option){
		case 1:
		{
			reqBean.setReqRmId(rmId);
			List<ProjectBean> prjBean = rm.getProjectDetails(rmId);
			for(ProjectBean prj : prjBean)
			{
				System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
			}
			System.out.println("Select the project to raise request");
			String prjId = scanner.next().toUpperCase();
			System.out.println("Enter the vacancy name : ");
			String vacancyName = scanner.next();
			System.out.println("Enter the skill : ");
			String skill = scanner.next().toLowerCase();
			System.out.println("Enter the domain : ");
			String domain = scanner.next().toLowerCase();
			System.out.println("Number required :");
			int noReq = scanner.nextInt();	
			reqBean.setReqProjectId(prjId);
			reqBean.setReqVacancyName(vacancyName);
			reqBean.setReqSkill(skill);
			reqBean.setReqDomain(domain);
			reqBean.setReqNoReq(noReq);
			String reqId = rm.raiseRequisition(reqBean);
			if(reqId!=null){
				System.out.println("Requisition raised with id : "+reqId);
			}
			else
			{
				System.out.println("Failed to raise");
			}
			
			break;
		}
		case 2:
		{
			
			break;
		}
		case 3:
		{
			
			break;
		}
		case 4:
		{
			
			break;
		}
		case 5:
			break;
		default:{
			System.out.println("Invalid choice");
		}
		}

	}

	public void rmgeService(UserBean bean){
		//IRMGEService rmge = new RMGEServiceImpl();
		System.out.println("RMGE Service\n1.Search employee\t2.View All Requisitions\t3.View Requisition of specific RM\t4.Generate report\t5.Exit");
		int option = scanner.nextInt();
		switch(option){
		case 1:
		{
			
			break;
		}
		case 2:
		{
			
			break;
		}
		case 3:
		{
			
			break;
		}
		case 4:
		{
			
			break;
		}
		case 5:
			break;
		default:{
			System.out.println("Invalid choice");
		}
		}
		
	}

}
