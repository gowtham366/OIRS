package com.oirs.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;
import com.oirs.service.AdminService;
import com.oirs.service.AuthenticateServiceImpl;
import com.oirs.service.IAdminService;
import com.oirs.service.IAuthenticateService;
import com.oirs.service.IRMService;
import com.oirs.service.RMServiceImpl;

/**
 * Servlet implementation class OIRSController
 */
@WebServlet("/OIRSController")
public class OIRSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public OIRSController() {
        super();
        // TODO Auto-generated constructor stub
    }
    userBean userbean = new userBean();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		IAdminService adminService = new AdminService();
		String option = request.getParameter("action");
		if(option.equals("LogIn")){
			String UserId = request.getParameter("userId");
			String userPassword = request.getParameter("userPassword");
			IAuthenticateService authService = new AuthenticateServiceImpl();
			try {
				userbean = authService.loginUser(UserId, userPassword);
				if(userbean != null){
					String beanRole = userbean.getUserRole().toLowerCase();
					String date =  userbean.getLastLogin();
					System.out.println(date);
					if(beanRole.equals("admin")){
						request.setAttribute("UserBean", userbean);
						request.setAttribute("logindate", userbean.getLastLogin());
						getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rm")){
						request.setAttribute("UserBean", userbean);
						getServletContext().getRequestDispatcher("/RmPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rmge"))
					{
						request.setAttribute("UserBean", userbean);
						getServletContext().getRequestDispatcher("/RmgePage.jsp").forward(request,response);
					}
					
					else{
					}
				}
				else
					out.println("Invalid UserName or Password");	
			}catch (OIRSException e) {}
			
		
		}
		else if(option.equals("Add New User"))
		{
			getServletContext().getRequestDispatcher("/addUser.jsp").forward(request,response);
		}
		else if(option.equals("Assign Role"))
		{
			getServletContext().getRequestDispatcher("/assignRole.jsp").forward(request,response);
		}
		else if(option.equals("Delete User"))
		{
			getServletContext().getRequestDispatcher("/DeleteUser.jsp").forward(request,response);
		}
		
		else if(option.equals("Adding New User"))
		{
			String newUserId = request.getParameter("newUserId");
			String newpswd = request.getParameter("newPwd");
			String newRole = request.getParameter("userRole");
			String newHint = request.getParameter("userHint");
			userbean.setUserId(newUserId);
			userbean.setUserPassword(newpswd);
			userbean.setUserRole(newRole);
			userbean.setHint(newHint);
			try {
				if(adminService.addNewUser(userbean).equals(null)){
					out.println("Details Not Inserted");
				}
				else{
					out.println("Data inserted succesfully");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Assigning"))
		{
			String assignUserId = request.getParameter("assignId");
			String assignRole = request.getParameter("assignRole");
			userbean.setUserId(assignUserId);
			userbean.setUserRole(assignRole);
			try {
				if(adminService.assignRole(assignUserId, assignRole).equals(null)){
					out.println("Assigning role failed");
				}
				else
				{
					out.println("succesfully assigned role");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Delete"))
		{
			String deleteUserId = request.getParameter("deleteUserId");
			userbean.setUserId(deleteUserId);
			try {
				if(adminService.deleteUser(deleteUserId).equals(null)){
					out.print("Delete cannot be done");
				}
				else{
					out.print("Deleted");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("RaiseRequisitions"))
		{
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = userbean.getUserId();
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetails(rmId);
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/RaiseRequisition.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Raise Requisition")){
			RequisitionBean reqBean = new RequisitionBean();
			IRMService rmService = new RMServiceImpl();
			ProjectBean projBean = new ProjectBean();
			String projId = request.getParameter("projId");
			String skill = request.getParameter("skill");
			String domain = request.getParameter("domain");
			int numReq = Integer.parseInt(request.getParameter("number"));
			String vacancy = request.getParameter("vacancy");
			reqBean.setReqProjectId(projId);
			reqBean.setReqSkill(skill);
			reqBean.setReqDomain(domain);
			reqBean.setReqVacancyName(vacancy);
			reqBean.setReqNoReq(numReq);
			try {
				 String reqId = rmService.raiseRequisition(reqBean);
				 if(reqId.equals(null))
				 {
					 out.println("Error in Raising Requisition");
				 }
				 else{
					 out.println("Requisition Raised Succesfully for Requisition Id "+reqId);
				 }
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Close/unassign")){
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = userbean.getUserId();
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetails(rmId);
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/closeUnasignProj.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		
		else if(option.equals("Close Project"))
		{
			String projId = request.getParameter("projId");
			IRMService rmService = new RMServiceImpl();
			System.out.println(projId);
			try {
				boolean result = rmService.unassignByPrjId(projId);
				if(result == true){
					out.println("Project Closed Succesfully");
				}
				else{
					out.println("Failed Closing the project");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Unassign Employee"))
		{
			IRMService rmService = new RMServiceImpl();
			
		}
	}
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
