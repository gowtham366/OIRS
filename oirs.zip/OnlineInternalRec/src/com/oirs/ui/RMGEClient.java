package com.oirs.ui;

public class RMGEClient {

}
