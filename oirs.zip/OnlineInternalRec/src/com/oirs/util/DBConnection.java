package com.oirs.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.oirs.exception.OIRSException;



/**
 * @author gowthc
 *
 */
public class DBConnection {

	private static Connection connection;


	public static Connection getConnection(){
		Connection conn=null;
			try {
				InitialContext ic=new InitialContext();
				DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			conn=ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return conn;
			
		}
}
